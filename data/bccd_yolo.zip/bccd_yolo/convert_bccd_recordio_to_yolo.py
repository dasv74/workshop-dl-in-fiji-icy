from pathlib import Path
import struct
import shutil
import zipfile
import numpy as np
from PIL import Image
from io import BytesIO

MAGIC = 0xCED7230A
CLASS_NAMES = ["RBC", "WBC", "Platelets"]


def read_idx(idx_path):
    entries = []
    for line in Path(idx_path).read_text().splitlines():
        if line.strip():
            rec_id, offset = map(int, line.split())
            entries.append((rec_id, offset))
    return entries


def unpack_detection_record(fp, offset):
    fp.seek(offset)
    magic, payload_size = struct.unpack("<II", fp.read(8))
    if magic != MAGIC:
        raise ValueError(f"Unexpected RecordIO magic: 0x{magic:08x}")

    payload = fp.read(payload_size)
    flag, first_label, rec_id, rec_id2 = struct.unpack("<IfQQ", payload[:24])

    jpeg_pos = payload.find(b"\xff\xd8\xff")
    if jpeg_pos < 0:
        raise ValueError("JPEG payload not found")

    # MXNet stores the first float in IRHeader.label and the rest immediately
    # after the 24-byte IRHeader. In these BCCD records, labels are:
    #   [0, 4, 5, width, height, class, xmin, ymin, xmax, ymax, ...]
    rest = np.frombuffer(payload[24:jpeg_pos], dtype="<f4")
    labels = np.concatenate(([np.float32(first_label)], rest))

    if len(labels) < 5 or (len(labels) - 5) % 5 != 0:
        raise ValueError(f"Unexpected detection label layout ({len(labels)} floats)")

    boxes = labels[5:].reshape(-1, 5).astype(np.float64)
    jpeg = payload[jpeg_pos:]
    return jpeg, boxes


def convert_split(src_dir, out_dir, split):
    rec_path = src_dir / f"{split}.rec"
    idx_path = src_dir / f"{split}.idx"
    image_dir = out_dir / "images" / split
    label_dir = out_dir / "labels" / split
    image_dir.mkdir(parents=True, exist_ok=True)
    label_dir.mkdir(parents=True, exist_ok=True)

    entries = read_idx(idx_path)
    class_counts = {0: 0, 1: 0, 2: 0}
    n_boxes = 0

    with rec_path.open("rb") as fp:
        for rec_id, offset in entries:
            jpeg, boxes = unpack_detection_record(fp, offset)

            # Keep IDs compatible with the original BCCD naming convention.
            stem = f"BloodImage_{rec_id:05d}"
            image_path = image_dir / f"{stem}.jpg"
            image_path.write_bytes(jpeg)

            # Sanity-check actual image dimensions.
            with Image.open(BytesIO(jpeg)) as im:
                if im.size != (640, 480):
                    raise ValueError(f"Unexpected size {im.size} for record {rec_id}")

            lines = []
            for cls, xmin, ymin, xmax, ymax in boxes:
                cls = int(round(cls))
                if cls not in class_counts:
                    raise ValueError(f"Unexpected class id {cls}")
                if not (0 <= xmin <= 1 and 0 <= ymin <= 1 and 0 <= xmax <= 1 and 0 <= ymax <= 1):
                    raise ValueError(f"Out-of-range box in record {rec_id}: {(xmin,ymin,xmax,ymax)}")
                if xmax <= xmin or ymax <= ymin:
                    # The source RecordIO contains two degenerate RBC boxes
                    # (records 299 and 304). YOLO cannot represent zero-area boxes.
                    continue

                xc = (xmin + xmax) / 2.0
                yc = (ymin + ymax) / 2.0
                w = xmax - xmin
                h = ymax - ymin
                lines.append(f"{cls} {xc:.8f} {yc:.8f} {w:.8f} {h:.8f}")
                class_counts[cls] += 1
                n_boxes += 1

            (label_dir / f"{stem}.txt").write_text("\n".join(lines) + ("\n" if lines else ""))

    return len(entries), n_boxes, class_counts


def main():
    src = Path("bccd_rec")
    out = Path("bccd_yolo")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir()

    stats = {}
    for split in ("train", "val"):
        stats[split] = convert_split(src, out, split)

    yaml_text = """# BCCD blood-cell detection dataset converted from MXNet RecordIO\npath: .\ntrain: images/train\nval: images/val\n\nnc: 3\nnames:\n  0: RBC\n  1: WBC\n  2: Platelets\n"""
    (out / "data.yaml").write_text(yaml_text)

    readme = [
        "BCCD YOLO conversion",
        "====================",
        "",
        "Classes:",
        "  0 = RBC",
        "  1 = WBC",
        "  2 = Platelets",
        "",
    ]
    for split, (nimg, nbox, cc) in stats.items():
        readme.append(f"{split}: {nimg} images, {nbox} boxes (RBC={cc[0]}, WBC={cc[1]}, Platelets={cc[2]})")
    readme += [
        "",
        "YOLO label format: class_id x_center y_center width height",
        "Coordinates are normalized to [0, 1].",
    ]
    (out / "README.txt").write_text("\n".join(readme) + "\n")
    print("\n".join(readme))


if __name__ == "__main__":
    main()
