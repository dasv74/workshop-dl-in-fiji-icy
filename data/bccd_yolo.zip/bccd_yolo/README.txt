BCCD YOLO conversion
====================

Classes:
  0 = RBC
  1 = WBC
  2 = Platelets

train: 328 images, 4417 boxes (RBC=3748, WBC=335, Platelets=334)
val: 36 images, 469 boxes (RBC=405, WBC=37, Platelets=27)

YOLO label format: class_id x_center y_center width height
Coordinates are normalized to [0, 1].
